const experience = [
  {
    category: "Digital media & news production",
    role: "Video Producer & Graphic Designer",
    organization: "LamjungKhabar · CNNKhabar · TilichoNews",
    summary:
      "News videos, editorial graphics and multimedia stories produced with speed, clarity and a consistent visual identity.",
  },
  {
    category: "Political campaigns & communication",
    role: "Digital Campaign Lead",
    organization: "Campaign of Prithvi Subba Gurung",
    summary:
      "Digital strategy, campaign videos, promotional reels, political branding and multi-platform audience engagement.",
  },
  {
    category: "Entertainment & social media",
    role: "Social Media Manager",
    organization: "Magne Raja — Nepali Feature Film",
    summary:
      "Managed the film's social media presence, including daily publishing, platform coordination and audience engagement.",
  },
  {
    category: "Political communication",
    role: "Freelance Political Designer",
    organization: "Nepali political leaders & organizations",
    summary:
      "Campaign identities, official communication materials, social creatives, posters and banners aligned with public messaging.",
  },
  {
    category: "Events & organizational media",
    role: "Graphic Designer & Video Editor",
    organization: "ANNFSU Student Festival 2024",
    summary:
      "Event branding, promotional graphics, teaser content, highlight videos and a cohesive social media campaign.",
  },
];

const services = [
  "Video Production",
  "Graphic Design",
  "Digital Campaign Strategy",
  "Political Communication",
  "Brand Identity",
  "Visual Storytelling",
];

const tools = [
  { name: "Adobe Photoshop", use: "Photo editing & design", mark: "Ps" },
  { name: "Adobe Premiere Pro", use: "Video editing & production", mark: "Pr" },
  { name: "Adobe Lightroom", use: "Photo processing", mark: "Lr" },
  { name: "Canva Pro", use: "Fast social content systems", mark: "Ca" },
];

const campaignDesigns = [
  {
    src: "/work/campaign-village.webp",
    alt: "Work from Village campaign design for Prithvi Subba Gurung",
  },
  {
    src: "/work/campaign-vote.webp",
    alt: "Election campaign portrait design for Prithvi Subba Gurung",
  },
  {
    src: "/work/campaign-field.webp",
    alt: "Field campaign and infrastructure communication design",
  },
  {
    src: "/work/campaign-countdown.webp",
    alt: "Election countdown social media design",
  },
];

const posterDesigns = [
  {
    src: "/work/poster-bidhya.webp",
    alt: "Commemorative editorial poster featuring Bidhya Devi Bhandari",
  },
  {
    src: "/work/poster-ishwor.webp",
    alt: "Political profile poster featuring Ishwor Pokharel",
  },
  {
    src: "/work/poster-surendra.webp",
    alt: "Economy themed editorial poster featuring Surendra Pandey",
  },
  {
    src: "/work/poster-rachana.webp",
    alt: "Campaign profile poster featuring Rachana Khadka",
  },
];

const studentFestivalDesigns = [
  {
    src: "/work/student-band.webp",
    alt: "ANNFSU Student Festival artist announcement design",
  },
  {
    src: "/work/student-launch.webp",
    alt: "ANNFSU Student Festival launch campaign design",
  },
  {
    src: "/work/student-lineup.webp",
    alt: "ANNFSU Student Festival performance lineup design",
  },
  {
    src: "/work/student-campus.webp",
    alt: "ANNFSU Student Festival campus campaign design",
  },
];

export default function Home() {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: "Nikshep Karki",
    jobTitle: "Video Producer, Graphic Designer & Digital Marketing Strategist",
    url: "https://www.nikshepkarki.com.np",
    email: "mailto:info.nikshepkarki@gmail.com",
    homeLocation: {
      "@type": "Place",
      name: "Lamjung & Kathmandu, Nepal",
    },
    sameAs: ["https://www.facebook.com/nikshepkarki.np"],
  };

  return (
    <main>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      <header className="site-header">
        <a className="brand" href="#top" aria-label="Nikshep Karki — home">
          Nikshep Karki<span>.</span>
        </a>
        <nav aria-label="Primary navigation">
          <a href="#about">About</a>
          <a href="#work">Work</a>
          <a href="#experience">Experience</a>
          <a href="#services">Services</a>
        </nav>
        <a className="header-contact" href="mailto:info.nikshepkarki@gmail.com">
          Contact <span aria-hidden="true">↗</span>
        </a>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">
            <span className="availability-dot" />
            Available for freelance & contract work
          </p>
          <h1>
            Nikshep
            <br />
            <span>Karki.</span>
          </h1>
          <p className="hero-role">
            Video Producer <i>·</i> Graphic Designer <i>·</i>
            <br />
            Digital Marketing Strategist
          </p>
          <p className="hero-intro">
            I turn ideas into clear, compelling visual stories that inform,
            engage and inspire.
          </p>
          <div className="hero-actions">
            <a className="button button-dark" href="#work">
              View selected work <span aria-hidden="true">↓</span>
            </a>
            <a className="button button-text" href="mailto:info.nikshepkarki@gmail.com">
              Start a project <span aria-hidden="true">↗</span>
            </a>
          </div>
        </div>

        <figure className="portrait-wrap">
          <div className="portrait-accent" aria-hidden="true" />
          <img
            src="/nikshep-karki.webp"
            alt="Portrait of Nikshep Karki"
            width="1000"
            height="1000"
            fetchPriority="high"
          />
          <figcaption>
            <span>Based in</span>
            Lamjung & Kathmandu, Nepal
          </figcaption>
        </figure>
      </section>

      <div className="expertise-bar" aria-label="Areas of expertise">
        {services.map((service) => (
          <span key={service}>{service}</span>
        ))}
      </div>

      <section className="about section" id="about">
        <div className="section-label">
          <span>01</span>
          <p>About</p>
        </div>
        <div className="about-content">
          <p className="about-lead">
            A multidisciplinary creative professional working where
            <em> visual storytelling</em> meets strategy.
          </p>
          <div className="about-body">
            <p>
              I specialize in video production, graphic design, digital
              branding and strategic marketing. My work combines strong visual
              communication with marketing insight to create content that is
              both compelling and effective.
            </p>
            <p>
              My experience spans digital journalism, political
              communications, entertainment marketing and organizational
              branding—creating for media organizations, public figures, film
              promotions and social campaigns.
            </p>
          </div>
          <div className="about-stats">
            <div>
              <strong>4+</strong>
              <span>Creative domains</span>
            </div>
            <div>
              <strong>12</strong>
              <span>Core capabilities</span>
            </div>
            <div>
              <strong>1</strong>
              <span>Purposeful approach</span>
            </div>
          </div>
        </div>
      </section>

      <section className="work section" id="work">
        <div className="section-label light">
          <span>02</span>
          <p>Selected work</p>
        </div>
        <div className="work-heading">
          <h2>Ideas made visible.</h2>
          <p>
            A focused selection across film marketing, political
            communication, news media and event branding.
          </p>
        </div>

        <article className="featured-project">
          <div className="featured-image">
            <img
              src="/work/magne-team.webp"
              alt="Magne Raja team at the cinema hall"
              width="1600"
              height="1066"
              loading="lazy"
            />
            <span>Featured project</span>
          </div>
          <div className="featured-copy">
            <p className="project-type">Entertainment & social media</p>
            <h3>Magne Raja</h3>
            <p>
              I handled social media for the Nepali feature film, managing
              publishing, platform coordination and audience engagement during
              its promotional campaign.
            </p>
            <dl>
              <div>
                <dt>Role</dt>
                <dd>Social Media Manager</dd>
              </div>
              <div>
                <dt>Type</dt>
                <dd>Feature Film Social Media</dd>
              </div>
              <div>
                <dt>Responsibilities</dt>
                <dd>Publishing · Scheduling · Audience Engagement</dd>
              </div>
            </dl>
          </div>
        </article>

        <div className="magne-media-grid">
          <div className="reel-card">
            <video
              autoPlay
              controls
              loop
              muted
              playsInline
              poster="/work/magne-reel-poster.webp"
              preload="metadata"
              aria-label="Magne Raja promotional reel"
            >
              <source src="/work/magne-reel.mp4" type="video/mp4" />
              Your browser does not support embedded video.
            </video>
            <div>
              <span>Social media promotion</span>
              <p>Promotional reel published through the film’s social channels.</p>
            </div>
          </div>
          <figure className="hall-card">
            <img
              src="/work/magne-hall.webp"
              alt="Magne Raja team during a cinema hall visit"
              width="1400"
              height="933"
              loading="lazy"
            />
            <figcaption>
              <span>Campaign presence</span>
              Cinema hall visit shared through the film’s social media
            </figcaption>
          </figure>
        </div>

        <div className="work-collection">
          <div className="collection-heading">
            <div>
              <p className="project-type">Political campaign communication</p>
              <h3>Prithvi Subba Gurung</h3>
            </div>
            <p>
              A scalable visual system for policy messages, voter outreach,
              festivals and daily campaign moments.
            </p>
          </div>
          <div className="campaign-gallery">
            {campaignDesigns.map((design, index) => (
              <figure key={design.src}>
                <img
                  src={design.src}
                  alt={design.alt}
                  width="1000"
                  height="1200"
                  loading="lazy"
                />
                <figcaption>{String(index + 1).padStart(2, "0")}</figcaption>
              </figure>
            ))}
          </div>
          <div className="collection-meta">
            <span>Campaign strategy</span>
            <span>Political branding</span>
            <span>Social media design</span>
            <span>Video production</span>
          </div>
        </div>

        <div className="work-collection collection-posters">
          <div className="collection-heading">
            <div>
              <p className="project-type">Editorial & political design</p>
              <h3>Poster selection</h3>
            </div>
            <p>
              Public communication designed for distinct people, messages and
              moments—kept coherent through composition and visual hierarchy.
            </p>
          </div>
          <div className="poster-gallery">
            {posterDesigns.map((design, index) => (
              <figure key={design.src} className={index === 2 ? "wide" : ""}>
                <img
                  src={design.src}
                  alt={design.alt}
                  width={index === 2 ? "1200" : "900"}
                  height={index === 2 ? "900" : "1200"}
                  loading="lazy"
                />
              </figure>
            ))}
          </div>
        </div>

        <div className="work-collection collection-student">
          <div className="collection-heading">
            <div>
              <p className="project-type">Event identity & social campaign</p>
              <h3>Student Festival 2024</h3>
            </div>
            <p>
              A youth-focused campaign system spanning artist announcements,
              launch graphics, schedules and campus communication.
            </p>
          </div>
          <div className="student-gallery">
            {studentFestivalDesigns.map((design) => (
              <figure key={design.src}>
                <img
                  src={design.src}
                  alt={design.alt}
                  width="1000"
                  height="1200"
                  loading="lazy"
                />
              </figure>
            ))}
          </div>
        </div>

        <div className="video-archive">
          <div>
            <p className="project-type">Long-form video</p>
            <h3>Documentaries & campaign films</h3>
          </div>
          <div className="video-links">
            <a
              href="https://drive.google.com/file/d/1cnu_eSin0dz6iGYufR-yHR_v24Xk1g_9/view"
              target="_blank"
              rel="noreferrer"
            >
              <span>Full documentary</span>
              Prithvi Subba Gurung — Struggle, Integrity & Development
              <b aria-hidden="true">↗</b>
            </a>
            <a
              href="https://drive.google.com/file/d/1bgJirUqnftJfVApBYLDilQmvSjPfZ6bJ/view"
              target="_blank"
              rel="noreferrer"
            >
              <span>Campaign music video</span>
              Janata Ko Saathma
              <b aria-hidden="true">↗</b>
            </a>
          </div>
        </div>
      </section>

      <section className="experience section" id="experience">
        <div className="section-label">
          <span>03</span>
          <p>Experience</p>
        </div>
        <div className="experience-heading">
          <h2>From newsrooms to campaigns and film sets.</h2>
          <p>
            A career shaped by real deadlines, diverse audiences and the need
            to make every message clear.
          </p>
        </div>
        <div className="experience-list">
          {experience.map((item, index) => (
            <article key={item.role + item.organization}>
              <span className="experience-number">
                {String(index + 1).padStart(2, "0")}
              </span>
              <p className="experience-category">{item.category}</p>
              <div className="experience-role">
                <h3>{item.role}</h3>
                <p>{item.organization}</p>
              </div>
              <p className="experience-summary">{item.summary}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="services section" id="services">
        <div className="section-label light">
          <span>04</span>
          <p>Skills & capabilities</p>
        </div>
        <div className="services-layout">
          <div>
            <h2>Creative thinking, practical execution.</h2>
            <p>
              From the first strategic question to the final exported frame, I
              bring the disciplines together.
            </p>
          </div>
          <div className="services-list">
            {services.map((service, index) => (
              <div key={service}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <h3>{service}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="tools section">
        <div className="section-label">
          <span>05</span>
          <p>Creative toolkit</p>
        </div>
        <div className="tools-heading">
          <h2>Tools are only useful when the idea is clear.</h2>
        </div>
        <div className="tools-grid">
          {tools.map((tool) => (
            <article key={tool.name}>
              <span className="tool-mark">{tool.mark}</span>
              <div>
                <h3>{tool.name}</h3>
                <p>{tool.use}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="philosophy">
        <p>Creative philosophy</p>
        <blockquote>
          “Great design is more than aesthetics. It is
          <em> purposeful communication.</em>”
        </blockquote>
      </section>

      <section className="contact section" id="contact">
        <div className="contact-intro">
          <p className="eyebrow">
            <span className="availability-dot" />
            Available for projects
          </p>
          <h2>Let&apos;s create something great.</h2>
          <p>
            Need cinematic video, impactful design or a strategic digital
            campaign? Tell me what you&apos;re building.
          </p>
        </div>
        <div className="contact-card">
          <p>Email</p>
          <a href="mailto:info.nikshepkarki@gmail.com">
            info.nikshepkarki@gmail.com <span aria-hidden="true">↗</span>
          </a>
          <p>Location</p>
          <strong>Lamjung & Kathmandu, Nepal</strong>
          <div className="contact-links">
            <a
              href="https://www.facebook.com/nikshepkarki.np"
              target="_blank"
              rel="noreferrer"
            >
              Facebook ↗
            </a>
            <a href="#top">Back to top ↑</a>
          </div>
        </div>
      </section>

      <footer>
        <a className="brand footer-brand" href="#top">
          Nikshep Karki<span>.</span>
        </a>
        <p>Video · Design · Strategy</p>
        <p>© 2026 Nikshep Karki</p>
      </footer>
    </main>
  );
}
