import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nikshep Karki — Video Producer, Graphic Designer & Strategist",
  description:
    "Portfolio of Nikshep Karki — video producer, graphic designer and digital marketing strategist based in Lamjung and Kathmandu, Nepal.",
  keywords: [
    "Nikshep Karki",
    "Video Producer Nepal",
    "Graphic Designer Nepal",
    "Digital Marketing Strategist Nepal",
    "Political Communication",
    "Visual Storytelling",
  ],
  authors: [{ name: "Nikshep Karki" }],
  openGraph: {
    title: "Nikshep Karki — Creative Portfolio",
    description:
      "Video production, graphic design, digital campaigns and visual storytelling.",
    type: "website",
    locale: "en_US",
  },
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
