# Upload Nikshep Karki Portfolio to GitHub

This package contains the complete professional portfolio source code and its
photo and video assets.

For **Magne Raja**, the portfolio lists the role accurately as **Social Media
Manager**, covering publishing, scheduling, platform coordination and audience
engagement.

Repository: <https://github.com/nikshepkarki9/Portfolio-Website>

## GitHub Desktop (recommended)

1. Extract the downloaded ZIP.
2. Open GitHub Desktop and clone `nikshepkarki9/Portfolio-Website`.
3. Copy the **contents** of the `Nikshep-Karki-Portfolio` folder into the cloned
   repository folder.
4. Review the changed files in GitHub Desktop.
5. Use the commit message `Update professional portfolio`.
6. Click **Commit to main**, then **Push origin**.

## Git command line

```bash
git clone https://github.com/nikshepkarki9/Portfolio-Website.git
cd Portfolio-Website
git checkout -b portfolio-redesign
```

Copy the extracted files into the cloned folder, then run:

```bash
git add .
git commit -m "Update professional portfolio"
git push -u origin portfolio-redesign
```

Create a Pull Request from `portfolio-redesign` into `main` on GitHub.

## Run locally

Install Node.js 22.13 or newer, then run:

```bash
npm install
npm run dev
```

Open the local address displayed in the terminal.

Do not upload `node_modules`, `dist`, `.next`, `.sites-runtime` or `.wrangler`.
These generated folders have already been excluded from this ZIP.
